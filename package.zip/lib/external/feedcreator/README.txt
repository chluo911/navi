Feedcreator-1.7.2-ppt, patched by Mohammad Hafiz bin Ismail

Legal
-------------
I hereby release my changes made into Feedcreator 1.7.2 under the terms of the GNU Lesser General Public License (GNU/LGPL)


Changes
-------------------------
- Add Atom 1.0 feed
- Add <enclosure> for RSS 2.0 and the similiar <link rel="enclosure"> for Atom 1.0
- Add EnclosureItem class that extends HtmlDescribable.


Changes by Fabian Wolf (info@f2w.de)
------------------------------------
- added output function outputFeed for on-the-fly feed generation


Other
---------------
- I MIGHT include pretty docs in the future, might.
- I've include a diff file against the vanilla feedcreator 1.7.2 for those who curious about what that Fabian and I have changed.



Original source code : http://www.bitfolge.de/rsscreator-en.html


