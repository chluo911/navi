<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Refresh" content="0;URL=navigate.php" />
    <title>Navigate CMS</title>
</head>
<body>
</body>
</html>